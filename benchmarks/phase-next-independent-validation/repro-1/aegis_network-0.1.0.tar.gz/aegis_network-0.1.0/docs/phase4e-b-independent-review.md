# Phase 4E-B independent contract and release review

The Phase 4D baseline remains valid for the existing disposable fixture. Finding **4C-02 remains open for distributed enforcement**. This review owns no implementation of the identity and fencing subsystem. The canonical implementation checkout is `feat/phase4e-identity`. This comparison and acceptance record lives on `feat/phase4e-b-fencing`.

## Verified baseline

Re-ran the T3 ownership and two Phase 3C ownership scenarios at `ae59a97becfdbf9fb79c7cc89c0a27c662fb9a9f`. **20 passed, four unrelated tests were deselected, and none failed or skipped**. The run exercised two actual disposable loopback NATS brokers on one host, one authoritative SQLite ownership home, the fixture writer and its established proof checks. In the two-broker test, each broker renews its own UUID lease even after the authoritative owner changes. The shared target cannot commit the old reviewed command, then accepts the new, exactly reviewed assignment. The two transport leases cannot grant a generation. The original T6 report and the test both identify the shared home transaction and the explicitly supplied peer/broker context. [T3 architecture](phase4d-t3-identity.md) · [Retained local compatibility record](../benchmarks/phase4e-b/t3-baseline-compat.json)

```sh
AEGIS_PHASE4D_T3_LIVE=1 PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=src \
  python -m pytest -q -ra -p no:cacheprovider \
  tests/phase4d/test_ownership.py tests/test_phase3c_pipeline.py \
  -k 'test_ownership or phase4d_ownership'
```

## Frozen inputs and proposed deployment boundaries

These are review criteria for a versioned lab proposal. The current signed bytes and APIs stay frozen.

| Boundary | Existing contract | Evidence for promotion |
| --- | --- | --- |
| Workload and broker | A canonical deployment UUID identifies the local audit. `IdentityLease` is scoped to one JetStream KV bucket. `OwnershipHome.accept` trusts the adapter's explicit peer and broker context and validates a distinct enrolled Ed25519 instance proof. | Derive workload URI from the verified TLS peer certificate, bind the accepted broker to the server-side enrollment and verify the server to the client. Store the exact URI, trust domain, allowed broker and key in governed enrollment. A TLS identity, KV success or matching UUID alone cannot grant enforcement. Retain expiration and per-broker credential scope through reconnect, and reject expired identities even if a channel stays open. |
| Command, local plan and time | The exact plan digest binds lease, target fences, Evidence, and ownership assignment. The current `LeaseProof` and `CommandProof` contain local monotonic deadlines. `LocalOperator` provisions approval independently. | Keep signed v1 proof encoding and local deadlines within their original host boundary. A remote boundary needs its own reviewed version, exact audience and bounded credential lifetime, an explicit clock-skew policy, and conservative conversion to local monotonic expiry. The minimum history, Evidence, plan, grant, lease and credential deadline wins. Deny on unknown clock or identity. |
| Activation and target barrier | `OwnershipHome` and the writer presently share one lock and state. Fencing consumes a generation, clears the assignment and prevents old commands at that store. | Use one authoritative home and pin an immutable writer inventory before beginning transfer. Persist a preparing state and stop issuing/renewing old grants. Carry authenticated, target-specific barrier receipts for the exact deployment, generation and inventory/transfer. Each writer installs the floor under its actual effect transaction lock and responds after durability. Issue the successor only after every enrolled protected, audit and authoritative cursor writer has proved its floor. A missing writer leaves transfer held. |
| Delivery and acknowledgements | Legacy delivery checks its broker-local lease before applying the event and confirms `ack_sync()` after the durable record. `process_message` has no home generation on the ACK and the broker lease can remain live during authoritative transfer. | Bind the physical subscriber, ACK scope and authority-bearing cursor operations to deployment and generation. Confirm that an old connection cannot advance successor state. A generation-specific physical consumer with a stable logical identity is one possible design. Preserve signed payloads, deduplication, replay positions, audited decisions and commit-before-confirmed-ACK. Neither broker delivery nor journal catch-up can bypass current status and local approval. |
| Restore and recovery | The colocated store can survive ordinary restart. The tests assume the SQLite home and fence files are trusted, current storage. | Protect home and per-writer state against rollback outside each restored failure domain. A generation-only floor cannot detect every same-generation replay, such as lost consumed-intent or authoritative cursor state. Pin the relevant state or prove replay is consistently idempotent. Missing anchors, ambiguous commits and older backups hold until authoritative continuity is independently established. Preserve quarantine before and after rejoin until exact fresh approval and health are verified. |

[Ownership implementation](../src/aegis/ownership.py) · [Target transaction](../src/aegis/mitigation/store.py) · [Delivery and ACK path](../src/aegis/agent_runtime.py) · [Frozen Phase 4 contracts](phase4-contract-review.md)

## Independent acceptance sequence

Run each fault with a healthy control and new isolated storage. Freeze the code revision, broker image IDs, listener/credential scope, inventory, clocks and fault schedule. The observer reads target state and the broker and audit records independently of the home and holder. Use monotonic durations measured on one host for each stage. Cross-host spans need a bounded clock method or a single observer clock.

| Case | Required observation |
| --- | --- |
| B1 · Authenticated admission and competing requests | Prove the valid pair of broker-authenticated workload and enrolled instance proof. Reject the wrong deployment URI, instance key, broker assignment, inactive or unknown credential, and replayed request. Concurrent contenders at two brokers can produce only one active home generation. |
| B2 · Transfer with one writer withheld | With two independently writable enrolled stores, confirm the first floor is committed and the second unavailable. No successor grant is issued. The already fenced target rejects the old command and a missing current authority produces safe hold. Recover the second target. Obtain both durable fences, then prove the successor with new exact approval can commit only its enrolled action. |
| B3 · Fence and retry ordering | Race an already-staged old operation against the barrier. A previous-generation write may commit before that target installs its floor, within its previous deadline. After the durable barrier, zero old writes may commit. Duplicate or delayed receipts cannot satisfy a new transfer or a different inventory. Preserve the effect, audit and consumed intent even if a response was lost. |
| B4 · Broker session and durable cursor | Pause the old worker around audit commit/ACK and fence it. Test closure or generation-isolation on the old physical consumer, including stale ACK from a previously valid connection, then recover the successor with no lost logical event or spurious cursor advancement. Check resume from an actual broker outage. |
| B5 · Rollback, long disconnect and stale clocks | Restore older home, writer and cursor snapshots separately while keeping independent recovery anchors current. Include an older snapshot within one generation, unavailable anchor and reconnect across credential expiration. A stale or ambiguous store issues no new authority. Prior known denials and restrictive serving persist, with no automatic reopen. |
| B6 · Combined guarded path | Run the composition with independently governed Mesh admission and Evidence services. Make status unavailable or withdrawn during transfer and after canary. Audit no unauthorized target mutation, verify all enrolled observations and require fresh exact local approval before a successor transition. |

The distributed acceptance runs need at least two explicitly authorized independent hosts, separate writable stores, identity and broker permissions actually enforced at each endpoint, a recoverable home and barriers on every writer. The baseline run had one physical host and shared administration. A split process, shared Colima VM or mock TLS adapter can establish intermediate contract behavior. They leave the physical multi-host, credential custody and operational failure gates open. Report counts for attempted/accepted generations, attempted/committed protected writes, observed unsafe paths and late or missing operations. Track authorization recovery, footprint and timing separately from ordinary transport fan-out.

## Review of the pinned canonical lab

The canonical identity branch has exact pin `cb7986d1abb7491e73f5ce53bb01778ba7159d94`, directly on the approved baseline. The amendment from `35fae604f1c4fca46644c3c2d561a1f9e2f20dfb` adds the missing `ClaimProof` import. The independent test run used an archive of the amended pin. **All 12 enabled cases passed** on loopback in 25.99 seconds, with no failures or skips. The earlier observed failures belong to the superseded source. [Retained case results](../benchmarks/phase4e-b/canonical-identity-tests.json)

- TLS 1.3 validates the CA chain and exact service URI. The broker verifies the workload URI and enrolled TLS public key, derives the broker from the endpoint role and checks the separately signed claim. An approved TLS peer alone cannot mutate any record.
- The home commits the preparing assignment before asking each enrolled target for a fence. Each target checks the pending assignment and commits its generation floor under the same SQLite transaction as the synthetic marker. The home checks the receipt for the exact assignment and target. It activates the assignment after both target commits. The mutation path separately checks the writer's floor, current home state, exact operator approval, version, nonce and deadline. The pinned cases exercise two competing brokers, partial transfer, former owner denial and older snapshots with an independent home anchor.
- The prototype preserves signed Mesh bytes and the existing Phase 4D fixture. It has separate HTTPS broker adapters with their own `/session` endpoint. Real JetStream consumer permissions, generation-bound ACK and cursor transitions, native Rapid, Mesh and Evidence status, clock-skew bounds and independent administrative custody remain outside those results.

### Recovery observation

One additional independent loopback run assigned the synthetic marker and then stopped and restarted the anchor without changing its state. The observer reported `observing → quarantined → observing`. The generation, version and sole mutation receipt stayed fixed through the interruption. This is a derived readback in the inert lab only. It reveals an integration boundary: the marker view recomputes eligibility from the current home, so locally observed quarantine is transient. Any proposed native serving adapter needs a durable interruption latch that keeps its restrictive state across restart, requires fresh exact local review, and has independent readback before reopening. Keep the marker service isolated. [Exact pinned readback](../benchmarks/phase4e-b/anchor-restart-readback.json)

Reproduce from an archived copy of the exact commit with the repository Python environment. Use only disposable loopback services and fixture credentials.

```sh
AEGIS_PHASE4E_LIVE=1 PYTHONPATH=src PYTHONDONTWRITEBYTECODE=1 \
  python -m pytest -q -ra -p no:cacheprovider tests/identity_lab
```

### Quarantine latch follow-up

The canonical follow-up `11ecb948de82ef094f4fc48261786ff7600d64de` persisted a hold in each writer's installed fence and quarantined the marker in the writer transaction. An observing read or a valid command whose current ownership check fails can set the hold. The ordinary successful path still requires exact current ownership, the target version and the distinct operator signature. An exact duplicate fence for a held assignment is rejected. A fresh preparing assignment with a higher generation installs a new fence and retains quarantine pending exact local approval. [Updated case results](../benchmarks/phase4e-b/canonical-identity-latch-tests.json)

The exact archived follow-up passed **13/13** enabled loopback tests in 27.75 seconds. A separate probe stopped the anchor, triggered a hold at one writer through observation and at the other through an otherwise valid command, then restarted the unchanged anchor and rebooted the first writer. Read-only SQLite verification showed both holds persisted at generation 1 with one original mutation receipt each. A same-generation write was rejected. Explicit retirement advanced to generation 2. A claim installed both generation 3 fences, leaving the marker quarantined. The old approval paired with the new command was rejected. Each writer recorded one new mutation after a fresh exact approval. This resolves the earlier recovery observation in the inert fixture. The physical multi-host, clock, broker ACK/cursor, combined status and operational restore gates remain open. [Independent latch and recovery readback](../benchmarks/phase4e-b/latched-anchor-restart-readback.json)
