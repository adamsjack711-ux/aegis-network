# Aegis 0.1.0 private tester guide

Use this bundle in a disposable **arm64 Linux** environment with CPython, venv and pip already available. On an Apple Silicon Studio, run the CLI inside a Linux VM or container. The inventory describes that Linux environment. A base OS and Python interpreter are prerequisites.

| Tested Linux OS | Tested CPython versions |
|---|---|
| Debian 13 arm64 | 3.12.16 and 3.13.18 |
| Ubuntu 24.04 arm64 | 3.12.13 and 3.13.14 |

Candidate `9ba94a84fd54ea9052d09e0c73bb6c365cbd5d5d` uses build-1 wheel SHA-256 `4afa7a6669b5f4b719be75bc53367cd4a52877ee59b831b056fb4a61072665b8`. Both private releases use the filename `aegis_network-0.1.0-py3-none-any.whl`. Identify this release by the commit and digest. Full immutable image IDs are in `metadata/validated-cells.json`. The wheelhouse contains the tested application and the union of the reviewed runtime wheels installed across those four images. Archive origins, versions, licenses and digests are in `metadata/dependencies.json`.

## 1. Verify the transfer and prepare read-only inputs

On the Studio, run `shasum -a 256 aegis-tester-9ba94a8.tar.gz` and compare it with the archive digest delivered separately. After a match, extract with `tar -xzf aegis-tester-9ba94a8.tar.gz` in a trusted private directory. The custodian controls that directory, its ancestors and the extracted files for the duration of the test. Mount the extracted directory **read-only** at `/bundle` for the non-root tester. Mount no host secrets or source checkout.

The included public grant list is empty. It grants authority to zero publishers. Plain status needs no grant. The optional empty-feed check below exercises the read-only grant path. For a later signed lab feed, the issuer supplies authenticated public publisher grants to the custodian separately. Verify the issuer and digest first. Use a regular file with mode 0444 under a 0555 directory, no symlinks, and protect all host ancestors and ACLs against replacement by the consumer. A read-only container mount alone cannot protect a mutable host source. Keep signing keys out of the bundle.

For example, with the approved Debian 13 / Python 3.12 image already available locally, start a fresh container from the directory containing the extracted bundle:

```sh
docker run --rm -it --pull=never --platform=linux/arm64 --network=none \
  --read-only --cap-drop=ALL --security-opt=no-new-privileges --user=65534:65534 \
  --tmpfs /tmp:rw,exec,nosuid,nodev,mode=1777,size=512m -e HOME=/tmp \
  -v "$PWD/aegis-tester-9ba94a8:/bundle:ro" --entrypoint sh \
  sha256:67898a5e53a2ebb1138a9e17b0dfb22e52aabca270854cf86d21372f179a003e
```

## 2. Verify and install offline

Run the following blocks in the same Linux shell. The checksum manifest covers the guide, fixtures, metadata and every wheel. The explicit application digest also ties the wheel to its independent validation.

```sh
set -eu
cd /bundle
sha256sum -c SHA256SUMS
echo '4afa7a6669b5f4b719be75bc53367cd4a52877ee59b831b056fb4a61072665b8  wheels/aegis_network-0.1.0-py3-none-any.whl' | sha256sum -c -
test "$(id -u)" != 0
test "$(uname -m)" = aarch64
test ! -w /bundle/grants
test ! -w /bundle/grants/trust.json
cd /tmp
venv=$(mktemp -d /tmp/aegis-tester.XXXXXX)
python3 -m venv "$venv"
. "$venv/bin/activate"
python -m pip --isolated install --no-index --no-cache-dir --only-binary=:all: \
  --find-links=/bundle/wheels /bundle/wheels/aegis_network-0.1.0-py3-none-any.whl
python -m pip --isolated check
test "$(command -v aegis)" = "$venv/bin/aegis"
```

## 3. Read status

```sh
rc=0
aegis status || rc=$?
echo "status exit=$rc"
test "$rc" = 2
```

Expect `mode: observation-only`, `network: offline` and `independent_status: unknown`. For this invocation, exit 2 accompanies an unknown assessment because no signed finding file or independent Evidence proof was supplied. Read the output as well as the exit code. Input errors can also return 2. Unknown establishes neither exposure nor protection.

To exercise the public grant fixture:

```sh
rc=0
aegis status --feed /bundle/empty-feed.json --trust /bundle/grants/trust.json || rc=$?
echo "empty-feed exit=$rc"
test "$rc" = 2
```

Expect `claim_count: 0` and unknown independent status. These commands request no persistent Aegis state.

## 4. Check the installed handoff module

This build ships the offline Scout → Investigator integration as a Python module, `aegis.intelligence.handoff`. Its `OfflineHandoff` class consumes a local Scout event using an explicit vulnerability ID, local asset and scripted provider. Its output is private research. The CLI status check above is separate. Import the module from the installed venv:

```sh
python -B -I -c 'from pathlib import Path; import sys; from aegis.intelligence import handoff; p = Path(handoff.__file__).resolve(); assert p.is_relative_to(Path(sys.prefix).resolve()); print(handoff.OfflineHandoff.__name__, p)'
```

## 5. Uninstall

```sh
python -m pip --isolated uninstall -y aegis-network
test ! -e "$venv/bin/aegis"
python -c 'import importlib.util, importlib.metadata as m; assert importlib.util.find_spec("aegis") is None and not list(m.distributions(name="aegis-network"))'
deactivate
echo 'Aegis uninstall verified.'
```

Exit the disposable container to discard the venv and its dependencies. This private test covers observation in the four recorded environments with custodian-controlled read-only grants.
